#!/bin/bash


echo "Backing up resolv.conf"
sudo cp /etc/resolv.conf /tmp/resolv.conf

echo "Installing needed packages..."
sudo apt-get -y update
sudo apt-get -y upgrade # include patched bluetooth stack

# disable interfering services
echo "Disabeling unneeded services to shorten boot time ..."
sudo update-rc.d ntp disable # not needed for stretch (only jessie)
sudo update-rc.d avahi-daemon disable
sudo update-rc.d dhcpcd disable
sudo update-rc.d networking disable
sudo update-rc.d avahi-daemon disable
sudo update-rc.d dnsmasq disable # we start this by hand later on

echo "Create udev rule for HID devices..."
# rule to set access rights for /dev/hidg* to 0666 
echo 'SUBSYSTEM=="hidg",KERNEL=="hidg[0-9]", MODE="0666"' > /tmp/udevrule
sudo bash -c 'cat /tmp/udevrule > /lib/udev/rules.d/99-usb-hid.rules'

# create 128 MB image for USB storage
echo "Creating 128 MB image for USB Mass Storage emulation"
mkdir -p $wdir/USB_STORAGE
dd if=/dev/P4wnP1 of=$wdir/USB_STORAGE/image.bin bs=1M count=128
mkdosfs $wdir/USB_STORAGE/image.bin

# create folder to store loot found
mkdir -p $wdir/collected


# create systemd service unit for P4wnP1 startup
# Note: switched to multi-user.target to make nexmon monitor mode work
if [ ! -f /etc/systemd/system/P4wnP1.service ]; then
        echo "Injecting P4wnP1 startup script..."
        cat <<- EOF | sudo tee /etc/systemd/system/P4wnP1.service > /dev/null
                [Unit]
                Description=P4wnP1 Startup Service
                #After=systemd-modules-load.service
                After=local-fs.target
                DefaultDependencies=no
                Before=sysinit.target

                [Service]
                #Type=oneshot
                Type=forking
                RemainAfterExit=yes
                ExecStart=/bin/bash $wdir/boot/boot_P4wnP1
                StandardOutput=journal+console
                StandardError=journal+console

                [Install]
                WantedBy=multi-user.target
                #WantedBy=sysinit.target
EOF
fi

sudo systemctl enable P4wnP1.service

if ! grep -q -E '^.+P4wnP1 STARTUP$' /home/pi/.profile; then
	echo "Adding P4wnP1 startup script to /home/pi/.profile..."
cat << EOF >> /home/pi/.profile
# P4wnP1 STARTUP
source /tmp/profile.sh
declare -f onLogin > /dev/null && onLogin
EOF
fi

# removing FSCK from fstab, as this slows down boot (jumps in on stretch nearly every boot)
echo "Disable FSCK on boot ..."
sudo sed -i -E 's/[12]$/0/g' /etc/fstab

# enable autologin for user pi (requires RASPBIAN JESSIE LITE, should be checked)
echo "Enable autologin for user pi..."
sudo ln -fs /etc/systemd/system/autologin@.service /etc/systemd/system/getty.target.wants/getty@tty1.service

# setup USB gadget capable overlay FS (needs Pi P4wnP1, but shouldn't be checked - setup must 
# be possible from other Pi to ease up Internet connection)
echo "Enable overlay filesystem for USB gadgedt suport..."
sudo sed -n -i -e '/^dtoverlay=/!p' -e '$adtoverlay=dwc2' /boot/config.txt

# add libcomposite to /etc/modules
echo "Enable kernel module for USB Composite Device emulation..."
if [ ! -f /tmp/modules ]; then sudo touch /etc/modules; fi
sudo sed -n -i -e '/^libcomposite/!p' -e '$alibcomposite' /etc/modules

echo "Removing all former modules enabled in /boot/cmdline.txt..."
sudo sed -i -e 's/modules-load=.*dwc2[',''_'a-zA-Z]*//' /boot/cmdline.txt

echo "Installing kernel update ..."
# still needed on current stretch releas, kernel 4.9.41+ ships still
# with broken HID gadget module (installing still needs a cup of coffee)
# Note:  last working Jessie version was the one with kernel 4.4.50+
#        stretch kernel known working is 4.9.45+ (only available via update right now)

# Raspbian stretch with Kernel >= 4.9.50+ needed for working bluetooth nap
#sudo rpi-update 913eddd6d23f14ce34ae473a4c080c5c840ed583 # force kernel 4.9.51+ for nexmon compatability

# Raspbian stretch with Kernel >= 4.9.78+ (working bluetooth, nexmon module compiled for this version)
sudo rpi-update 23a007716a0c6a8677097be859cf7063ae093d27

# ToDo: the correct branch of nexmon for the current update kernel should be checked out here,
#       to do this the downloaded kernel version has to be feteched, which is only available after reboot from `uname -r`
#       The logic to do this will be implemented in init_wifi_nexmon, to allow checking out the correct branch of "P4wnP1_nexmon_addition"
#       if it doesn't match the current kernel at runtime




echo
echo
echo "===================================================================================="
echo "If you came till here without errors, you shoud be good to go with your P4wnP1..."
echo "...if not - sorry, you're on your own, as this is work in progress"
echo 
echo "Attach P4wnP1 to a host and you should be able to SSH in with pi@172.16.0.1 (via RNDIS/CDC ECM)"
echo
echo "If you use a USB OTG adapter to attach a keyboard, P4wnP1 boots into interactive mode"
echo
echo "If you're using a Pi P4wnP1 W, a WiFi AP should be opened. You could use the AP to setup P4wnP1, too."
echo "          WiFi name:    P4wnP1"
echo "          Key:          MaMe82-P4wnP1"
echo "          SSH access:    pi@172.24.0.1 (password: raspberry)"
echo
echo "  or via Bluetooth NAP:    pi@172.26.0.1 (password: raspberry)"
echo
echo "Go to your installation directory. From there you can alter the settings in the file 'setup.cfg',"
echo "like payload and language selection"
echo 
echo "If you're using a Pi P4wnP1 W, give the HID backdoor a try ;-)"
echo
echo "You need to reboot the Pi now!"
echo "===================================================================================="

